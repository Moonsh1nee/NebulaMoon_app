const Habits = () => {
  return <h1>Habits Page</h1>;
};

export default Habits;
